package com.example.noticeboard

class ModelRecord (
    var id: String,
    var name: String,
    var address: String,
    var image: String,
    var time: String,
    var contentt : String,
    var addedTime:String,
    var updatedTime:String
)